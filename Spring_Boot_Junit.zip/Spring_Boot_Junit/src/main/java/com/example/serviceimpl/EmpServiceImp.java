package com.example.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.exception.ResourceNotFoundException;
import com.example.model.Emp;
import com.example.repository.EmpRepo;
import com.example.service.EmpService;
@Service
public class EmpServiceImp implements EmpService {
	
	private EmpRepo emprepo;

	public EmpServiceImp(EmpRepo emprepo) {
		this.emprepo=emprepo;
		// TODO Auto-generated constructor stub
	}

	@Override
	public Emp saveEmp(Emp emp) {
		Optional<Emp> findById = emprepo.findByFirstName(emp.getFirstName());
		if(findById.isPresent()) {
			throw new ResourceNotFoundException("firstname is already exist");
		}
		// TODO Auto-generated method stub
		return emprepo.save(emp);
	}
    @Override
    public List<Emp> getAllEmployees() {
        return emprepo.findAll();
    }

   

    @Override
    public Emp updateEmployee(Emp updatedEmployee) {
        return emprepo.save(updatedEmployee);
    }
    @Override
    public Optional<Emp> getEmployeeById(Integer id) {
        return emprepo.findById(id);
    }

}
