package com.example.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.Emp;

public interface EmpRepo extends JpaRepository<Emp, Integer>{

	Optional<Emp> findByFirstName(String firstName);

}
