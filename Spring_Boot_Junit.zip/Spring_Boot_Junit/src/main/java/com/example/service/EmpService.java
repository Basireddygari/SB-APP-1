package com.example.service;

import java.util.List;
import java.util.Optional;

import com.example.model.Emp;

public interface EmpService {
	Emp saveEmp(Emp emp);
	List<Emp> getAllEmployees();
	Emp updateEmployee(Emp updatedEmployee);
	Optional<Emp> getEmployeeById(Integer id);
}
