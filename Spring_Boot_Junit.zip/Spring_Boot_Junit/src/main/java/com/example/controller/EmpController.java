package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Emp;
import com.example.service.EmpService;

@RestController
public class EmpController {
	@Autowired
	private EmpService empser;
	@PostMapping("/createemployee")
	public ResponseEntity<Emp> createEmp(@RequestBody Emp e) {
		return new ResponseEntity<Emp>(empser.saveEmp(e),HttpStatus.CREATED);
	}
	   @GetMapping("/getallemp")
	    public List<Emp> getAllEmployees(){
	        return empser.getAllEmployees();
	    }

	    @GetMapping("/getid/{id}")
	    public ResponseEntity<Emp> getEmployeeById(@PathVariable("id") Integer employeeId){
	        return empser.getEmployeeById(employeeId)
	                .map(ResponseEntity::ok)
	                .orElseGet(() -> ResponseEntity.notFound().build());
	    }

}
