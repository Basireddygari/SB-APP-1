package com.example.service;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willDoNothing;
import static org.mockito.Mockito.*;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;


import com.example.exception.ResourceNotFoundException;
import com.example.model.Emp;
import com.example.repository.EmpRepo;
import com.example.serviceimpl.EmpServiceImp;


@ExtendWith(MockitoExtension.class)
public class EmpServiceTest {
	
	@Mock
	private EmpRepo emprepo;
	@InjectMocks
	private EmpServiceImp empser;
	private Emp emp;
	@BeforeEach
	public void setup() {
		//emprepo = Mockito.mock(EmpRepo.class);
		//empser=new EmpServiceImp(emprepo);
		emp=new Emp();
		emp.setFirstName("lalliiiii");
		emp.setId(8);
		emp.setLastName("reddyy");

	}
	/*
	 * @Test public void givenEmpObj_whenEmpSave_thenReturnSaveEmp() { //given
	 * System.out.println(emp);
	 * BDDMockito.given(emprepo.findByFirstName(emp.getFirstName())).willReturn(
	 * Optional.empty()); BDDMockito.given(emprepo.save(emp)).willReturn(emp);
	 * 
	 * //when System.out.println("saaaaaaaaaa"); Emp saveEmp = empser.saveEmp(emp);
	 * System.out.println(saveEmp); // Optional<Emp> findByFirstName =
	 * emprepo.findByFirstName(emp.getFirstName()); //then
	 * Assertions.assertThat(saveEmp).isNotNull();
	 * //Assertions.assertThat(emp.getId()).isGreaterThan(2); }
	 */

    // JUnit test for getAllEmployees method
    @DisplayName("JUnit test for getAllEmployees method")
    @Test
    public void givenEmpList_whenGetAllEmp_thenReturnEmpList(){
        // given - precondition or setup

		Emp emp1=new Emp();
		emp.setFirstName("suguna");
		emp.setId(1);
		emp.setLastName("reddyy");

        given(emprepo.findAll()).willReturn(List.of(emp,emp1));

        // when -  action or the behaviour that we are going test
        List<Emp> employeeList = empser.getAllEmployees();

        // then - verify the output
        assertThat(employeeList).isNotNull();
        assertThat(employeeList.size()).isEqualTo(2);
    }
    // JUnit test for updateEmployee method
    @DisplayName("JUnit test for updateEmployee method")
    @Test
    public void givenEmpObject_whenUpdateEmp_thenReturnUpdatedEmp(){
        // given - precondition or setup
        given(emprepo.save(emp)).willReturn(emp);
        emp.setLastName("veni");
        emp.setFirstName("Ram");
        // when -  action or the behaviour that we are going test
        Emp updatedEmployee = empser.updateEmployee(emp);

        // then - verify the output
        assertThat(updatedEmployee.getFirstName()).isEqualTo("ram");
        assertThat(updatedEmployee.getLastName()).isEqualTo("veni");
    }


}
