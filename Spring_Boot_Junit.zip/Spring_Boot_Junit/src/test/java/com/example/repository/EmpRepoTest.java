package com.example.repository;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.example.model.Emp;

@DataJpaTest
public class EmpRepoTest {
	@Autowired
	private EmpRepo emprepo;
	@DisplayName("junit test case for get emp details:")
	@Test
	public void givenEmpObj_whenEmpSave_thenReturnSaveEmp() {
	//given
		Emp emp=new Emp();
		emp.setFirstName("suguna");
		emp.setId(3);
		emp.setLastName("reddy");
		System.out.println(emp);
	//when
		Emp empsave = emprepo.save(emp);
	//then
		Assertions.assertThat(empsave).isNotNull();
		Assertions.assertThat(emp.getId()).isGreaterThan(0);
	}

}
