package com.example.controller;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import com.example.model.Emp;
import com.example.service.EmpService;
import com.fasterxml.jackson.databind.ObjectMapper;

import jdk.jfr.ContentType;
@WebMvcTest
public class EmpControllerTest {
	@Autowired
	private MockMvc mockmvc;
	
	@MockBean
	private EmpService empser;
	@Autowired
private ObjectMapper objmap;
	@Test
	public void givenEmpObj_whenCreateEmp_thenReturnSavedEmpObj() throws Exception {
		Emp e=new Emp();
		e.setFirstName("suji");
		e.setLastName("reddyyy");
		e.setId(9);
		given(empser.saveEmp(any(Emp.class))).willAnswer((invocation)->invocation.getArgument(0));
		//When
		ResultActions response=mockmvc.perform(post("/createemployee")
				.contentType(org.springframework.http.MediaType.APPLICATION_JSON)
				.content(objmap.writeValueAsString(e)));
		//then
	response.andDo(print())
	.andExpect(status().isCreated())
	.andExpect(jsonPath("$.firstName", is(e.getFirstName())))
	.andExpect( jsonPath("$.id", is(e.getId())))
	.andExpect(  jsonPath("$.lastName", is(e.getLastName())));
	}
	
	
	
    // JUnit test for Get All employees REST API
    @Test
    public void givenListOfEmp_whenGetAllEmp_thenReturnEmpList() throws Exception{
        // given - precondition or setup
		Emp e=new Emp();
		e.setFirstName("suji");
		e.setLastName("reddyyy");
		e.setId(9);
		Emp e1=new Emp();
		e1.setFirstName("veni");
		e1.setLastName("reddyyy");
		e1.setId(3);
		
        given(empser.getAllEmployees()).willReturn(List.of(e,e1));

        // when -  action or the behaviour that we are going test
        ResultActions response = mockmvc.perform(get("/getallemp"));

        // then - verify the output
        response.andExpect(status().isOk())
                .andDo(print())
                .andExpect(jsonPath("$.size()",
                        is(List.of(e,e1).size())));

    }

    // positive scenario - valid employee id
    // JUnit test for GET employee by id REST API
    @Test
    public void givenEmployeeId_whenGetEmployeeById_thenReturnEmployeeObject() throws Exception{
        // given - precondition or setup
        Integer employeeId = 1;
		Emp e=new Emp();
		e.setFirstName("john");
		e.setLastName("reddyyy");
		e.setId(9);
        given(empser.getEmployeeById(employeeId)).willReturn(Optional.of(e));

        // when -  action or the behaviour that we are going test
        ResultActions response = mockmvc.perform(get("/getid/{id}", employeeId));

        // then - verify the output
        response.andExpect(status().isOk())
                .andDo(print())
                .andExpect(jsonPath("$.firstName", is(e.getFirstName())))
                .andExpect(jsonPath("$.lastName", is(e.getLastName())))
                .andExpect(jsonPath("$.id", is(e.getId())));

    }
}
