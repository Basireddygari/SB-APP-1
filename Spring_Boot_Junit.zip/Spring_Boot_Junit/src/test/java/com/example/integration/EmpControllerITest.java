package com.example.integration;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import com.example.model.Emp;
import com.example.service.EmpService;
import com.fasterxml.jackson.databind.ObjectMapper;
@SpringBootTest
public class EmpControllerITest {
	@Autowired
	private MockMvc mockmvc;
	
	@MockBean
	private EmpService empser;
	@Autowired
private ObjectMapper objmap;
	@Test
	public void givenEmpObj_whenCreateEmp_thenReturnSavedEmpObjj() throws Exception {
		Emp e=new Emp();
		e.setFirstName("suji");
		e.setLastName("reddyyy");
		e.setId(9);
		//given(empser.saveEmp(any(Emp.class))).willAnswer((invocation)->invocation.getArgument(0));
		//When
		ResultActions response=mockmvc.perform(post("/createemployee")
				.contentType(org.springframework.http.MediaType.APPLICATION_JSON)
				.content(objmap.writeValueAsString(e)));
		//then
	response.andDo(print())
	.andExpect(status().isCreated())
	.andExpect(jsonPath("$.firstName", is(e.getFirstName())))
	.andExpect( jsonPath("$.id", is(e.getId())))
	.andExpect(  jsonPath("$.lastName", is(e.getLastName())));
	}
}
