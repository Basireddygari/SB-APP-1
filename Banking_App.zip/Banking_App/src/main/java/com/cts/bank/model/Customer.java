package com.cts.bank.model;

import org.springframework.stereotype.Component;

@Component
public class Customer {
	private String name;
	private String accNo;
	private Integer amount;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", accNo=" + accNo + ", amount=" + amount + "]";
	}
	
}
