package com.cts.bank.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cts.bank.dao.BankDao;
import com.cts.bank.model.Customer;
@Component
public class Bankdto {
	@Autowired
	private BankDao bdao;
	@Autowired
	private Customer c;
	
	
	
	public String checkBalance() {
		c.setAccNo("as2332");
		c.setName("suguna");
		c.setAmount(20000);
		return bdao.balanceCheck(c.getAccNo(),c.getAmount());
	}
	public String DepositeAmout() {
		return bdao.Deposite(c.getAccNo(),6000);
	}
	public String withdrawAmout() {
		return bdao.withdraw(c.getAccNo(),3000);
	}
	
	

}
