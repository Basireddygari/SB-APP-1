package com.cts.bank.service;


import org.springframework.stereotype.Service;

import com.cts.bank.dao.BankDao;

@Service
public class BankService implements BankDao{
		public String withdraw(String accno,int n) {
		return n+"  successfully withdraw the amount";
	}
	public String balanceCheck(String accno,int n) {
		
		return "balance amount is ------"+n;
	}
	public String Deposite(String accno,int n) {
		return "successfully Deposite the amount--"+n;
	}

}
