package com.cts.bank.dao;

import org.springframework.stereotype.Repository;

@Repository
public interface BankDao {
	String withdraw(String accno,int n);
	String balanceCheck(String accno,int n);
	String Deposite(String accno,int n);

}
