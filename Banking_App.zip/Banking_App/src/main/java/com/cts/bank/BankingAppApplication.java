package com.cts.bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.cts.bank.dto.Bankdto;

@SpringBootApplication
public class BankingAppApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext run = SpringApplication.run(BankingAppApplication.class, args);
		Bankdto bean = run.getBean(Bankdto.class);
		String checkBalance = bean.checkBalance();
		String depositeAmout = bean.DepositeAmout();
		String withdrawAmout = bean.withdrawAmout();
		System.out.println(checkBalance);
		System.out.println(depositeAmout);
		System.out.println(withdrawAmout);
	}

}
